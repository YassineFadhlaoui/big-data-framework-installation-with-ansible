/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.congiv.schemas;

import com.congiv.configReader.ConfigurationReader;
import java.util.Properties;
import java.util.Vector;
import org.apache.log4j.Logger;

/**
 *
 * @author occ
 */
public class MqttMessageFieldsIndexer {

    int mqttMessageFieldsNumber;
    int clientIdPosition;
    int meterIdPosition;
    int metricNamePosition;
    int datestampPosition;
    int timestampPosition;
    int utcSecondsDeltaPosition;
    int metricValueposition;
    int deltaValuePosition;
    int unitPosition;
    String openTSDBAllowedChars;

    //overload constructor (read fields index from conf file)   
    public MqttMessageFieldsIndexer(Logger logger, Properties JAVAProps) {

        ConfigurationReader cr = new ConfigurationReader();
        Vector<String> Parameters = new Vector();
        Parameters.add("MQTT_MESSAGE_FIELDS_NUMBER");
        Parameters.add("CLIENT_ID_POSITION");
        Parameters.add("METER_ID_POSITION");
        Parameters.add("METRIC_NAME_POSITION");
        Parameters.add("DATESTAMP_POSITION");
        Parameters.add("TIMESTAMP_POSITION");
        Parameters.add("UTC_SECONDS_DELTA_POSITION");
        Parameters.add("METRIC_VALUE_POSITION");
        Parameters.add("DELTA_VALUE_POSITION");
        Parameters.add("UNIT_POSITION");
        Parameters.add("OPENTSDB_ALLOWED_CHARS");
        logger.info("reading MQTT message structure and fields positions from config file");
        Vector<String> params = cr.getProperties(JAVAProps, Parameters, logger);
        this.mqttMessageFieldsNumber = Integer.parseInt(params.get(0));
        this.clientIdPosition = Integer.parseInt(params.get(1));
        this.meterIdPosition = Integer.parseInt(params.get(2));
        this.metricNamePosition = Integer.parseInt(params.get(3));
        this.datestampPosition = Integer.parseInt(params.get(4));
        this.timestampPosition = Integer.parseInt(params.get(5));
        this.utcSecondsDeltaPosition = Integer.parseInt(params.get(6));
        this.metricValueposition = Integer.parseInt(params.get(7));
        this.deltaValuePosition = Integer.parseInt(params.get(8));
        this.unitPosition = Integer.parseInt(params.get(9));
        this.openTSDBAllowedChars = params.get(10);
    }
//default constructor

    public String getOpenTSDBAllowedChars() {
        return openTSDBAllowedChars;
    }

    public MqttMessageFieldsIndexer(int mqttMessageFieldsNumber, int clientIdPosition, int meterIdPosition, int metricNamePosition, int datestampPosition, int timestampPosition, int utcSecondsDeltaPosition, int metricValueposition, int deltaValuePosition, int unitPosition, String openTSDBAllowedChars) {
        this.mqttMessageFieldsNumber = mqttMessageFieldsNumber;
        this.clientIdPosition = clientIdPosition;
        this.meterIdPosition = meterIdPosition;
        this.metricNamePosition = metricNamePosition;
        this.datestampPosition = datestampPosition;
        this.timestampPosition = timestampPosition;
        this.utcSecondsDeltaPosition = utcSecondsDeltaPosition;
        this.metricValueposition = metricValueposition;
        this.deltaValuePosition = deltaValuePosition;
        this.unitPosition = unitPosition;
        this.openTSDBAllowedChars = openTSDBAllowedChars;
    }

    public int getMqttMessageFieldsNumber() {
        return mqttMessageFieldsNumber;
    }

    public int getClientIdPosition() {
        return clientIdPosition;
    }

    public int getMeterIdPosition() {
        return meterIdPosition;
    }

    public int getMetricNamePosition() {
        return metricNamePosition;
    }

    public int getDatestampPosition() {
        return datestampPosition;
    }

    public int getTimestampPosition() {
        return timestampPosition;
    }

    public int getUtcSecondsDeltaPosition() {
        return utcSecondsDeltaPosition;
    }

    public int getMetricValueposition() {
        return metricValueposition;
    }

    public int getDeltaValuePosition() {
        return deltaValuePosition;
    }

    public int getUnitPosition() {
        return unitPosition;
    }

}

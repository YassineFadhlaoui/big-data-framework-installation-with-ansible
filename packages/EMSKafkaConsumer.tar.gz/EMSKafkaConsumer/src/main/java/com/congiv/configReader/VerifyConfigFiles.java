/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.congiv.configReader;

import java.io.File;

/**
 *
 * @author yassine
 */
public class VerifyConfigFiles {
    public void isConfigFilesThere(){
    
        File log4jConfig = new  File("/etc/EMSKafkaConsumer/log4j.conf");
        File EMSKafkaConsumerConf = new File("/etc/EMSKafkaConsumer/EMSKafkaConsumer.conf");
        File EMSKafkaConsumerLog = new File("/var/log/EMSKafkaConsumer");
        File KafkaSubscriberConf = new File("/etc/EMSKafkaConsumer/KafkaSubscriber.conf");
        
        if(!log4jConfig.exists()) {
            System.out.println("log4j properties file is missing. Please copy it to /etc/EMSKafkaConsumer/log4j.conf (with read permission)");
            System.exit(1);
        }
        if(!log4jConfig.canRead()) {
            System.out.println("cannot read /etc/EMSKafkaConsumer/log4j.conf. Please add read permission to it");
            System.exit(2);
        }
        if(!EMSKafkaConsumerConf.exists()) {
            System.out.println("EMSKafkaConsumer properties file is missing. Please copy it to /etc/EMSKafkaConsumer/EMSKafkaConsumer.conf (with read permission)");
            System.exit(3);
        }
        if(!EMSKafkaConsumerConf.canRead()) {
            System.out.println("cannot read /etc/EMSKafkaConsumer/EMSKafkaConsumer.conf. Please add read permission to it");
            System.exit(4);
        }
        if(!KafkaSubscriberConf.exists()){
            System.out.println("kafaka subscriber properties file is missing. Please add it under /etc/EMSKafkaConsumer/KafkaSubscriber.conf");
            System.exit(5);
        }
        if(!KafkaSubscriberConf.canRead()){
            System.out.println("kafaka subscriber properties file cannot be read please add read permission to it:  /etc/EMSKafkaConsumer/KafkaSubscriber.conf");
            System.exit(5);
        }
        if(!EMSKafkaConsumerLog.exists()){
            System.out.println("Log folder is missing. Please add it under /var/log/EMSKafkaConsumer");
            System.exit(7);
        }
        if(!EMSKafkaConsumerLog.canWrite()){
            System.out.println("cannot write log files to /var/log/EMSKafkaConsumer. Please add write + read permissions to it");
            System.exit(8);
        }
    }
}

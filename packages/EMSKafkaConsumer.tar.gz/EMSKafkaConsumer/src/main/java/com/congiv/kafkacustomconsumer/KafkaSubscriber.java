package com.congiv.kafkacustomconsumer;

import com.congiv.configReader.ConfigurationReader;
import java.util.Arrays;
import java.util.Properties;
import java.util.Vector;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.log4j.Logger;
import com.congiv.CustomException.BrokerConnectionException;
import com.congiv.CustomException.TopicNotFoundException;
import java.util.List;
import java.util.Map;
import org.apache.kafka.common.PartitionInfo;

/**
 *
 * @author occ
 */
public class KafkaSubscriber {

    Properties kafkaSubscriberProperties;
    String KafkaTopic;
    int maxreconnectAttempts;
    static int counter = 1;

    public KafkaSubscriber(Properties kafkaSubscriberProperties, String KafkaTopic, int maxreconnectAttempts) {
        this.kafkaSubscriberProperties = kafkaSubscriberProperties;
        this.KafkaTopic = KafkaTopic;
        this.maxreconnectAttempts = maxreconnectAttempts;
    }

    //Overload the constructor read topic directly from config file and max reconnect attempts
    public KafkaSubscriber(Properties kafkaSubscriberProperties, Properties props, Logger logger) {
        this.kafkaSubscriberProperties = kafkaSubscriberProperties;
        ConfigurationReader cr = new ConfigurationReader();
        Vector<String> Parameters = new Vector();
        Parameters.add("KAFKA_TOPIC");
        Parameters.add("MAX_RECONNECT_ATTEMPTS");
        logger.info("reading Kafka Topic and maximum reconnect attempts from config file");
        Vector<String> params = cr.getProperties(props, Parameters, logger);
        String kafkaTopic = params.get(0);
        int maxReconnectAttempts = Integer.parseInt(params.get(1));
        this.KafkaTopic = kafkaTopic;
        this.maxreconnectAttempts = maxReconnectAttempts;
    }

    public String getKafkaTopic() {
        return KafkaTopic;
    }
    public int getMaxreconnectAttempts() {
        return maxreconnectAttempts;
    }
    public Properties getKafkaSubscriberProperties() {
        return kafkaSubscriberProperties;
    }

    public KafkaConsumer<String, String> SubscribeToBroker(Logger logger) throws BrokerConnectionException {
        KafkaConsumer<String, String> kafkaConsumer = new KafkaConsumer<>(kafkaSubscriberProperties);
        try {
            logger.info("Subscribing to Kafka broker");
            kafkaConsumer.subscribe(Arrays.asList(KafkaTopic));
            kafkaConsumer.seekToBeginning(kafkaConsumer.assignment());
            //Now make sure that the topic that we are subscribing to is there
            Map<String, List<PartitionInfo>> TopicsList = kafkaConsumer.listTopics();
            boolean isTopicFound = TopicsList.containsKey(KafkaTopic);
            if (isTopicFound) {
                logger.info("Subscribption done successfully");
                logger.info("Topic " + KafkaTopic + " was found in the Kafka topics  List");
                System.out.println(isTopicFound);
                return kafkaConsumer;
            } else {

                logger.error("Not able to find the topic: " + KafkaTopic + " in the topics list");
                throw new TopicNotFoundException("not able to find topic " + KafkaTopic + " in the topics list\n please make sure that the topic exists\n make sure that the mqtt plugin is configured correctly");
            }

        } catch (Exception ex) {
            logger.fatal("Not able to subscribe to Kafka broker: " + ex.getMessage());
            System.out.println("not able to subscribe to kafka broker: " + ex.getMessage());
            logger.info("Trying to reconnect: Attempt number " + String.valueOf(counter));
            tryToReconnect(logger);
        }
        throw new BrokerConnectionException("all connection attemots failed. Please verify that the broker is up and the configuration is correct");
    }

    private void tryToReconnect(Logger logger) {
        try {
            if (counter <= maxreconnectAttempts) {
                System.out.println("attempt: " + counter);
                counter++;
                SubscribeToBroker(logger);
            } else {
                logger.fatal("All connection attempts failed--leaving with exit code 2");
            }
        } catch (Exception ex) {
            System.out.println(ex);
            logger.fatal("Exception: Cannot start the reconnection process " + ex.getMessage());
        }
    }
}

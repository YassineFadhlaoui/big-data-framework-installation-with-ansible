package com.congiv.kafkacustomconsumer;

import com.congiv.CustomException.OpenTSDBNotReachableException;
import com.congiv.configReader.ConfigurationReader;
import com.congiv.schemas.MqttMessage;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.StandardCharsets;
import java.util.Properties;
import java.util.Vector;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.log4j.Logger;

/**
 *
 * @author occ
 */
public class OpenTSDBConnector {

    private static final String HTTP_BODY_CONTENT_TYPE = "application/json; charset=UTF-8";
    private static final int HTTP_RESPONSE_SUCCESS_CODE = 200;
    private static final int HTTP_RESPONSE_SUCCESS_CODE_EMPTY_BODY=204;
    private String openTSDBServer;
    private String openTSDBPort;
    private String openTSDBHttpMethod;
    private String openTSDBHttpUri;
    private MqttMessage mqttMessage;

    private Logger logger;

    //normal constructor
    public OpenTSDBConnector(String openTSDBServer, String openTSDBPort, String openTSDBHttpMethod, String openTSDBHttpUri, MqttMessage mqttMessage, Logger logger) {
        this.openTSDBServer = openTSDBServer;
        this.openTSDBPort = openTSDBPort;
        this.openTSDBHttpMethod = openTSDBHttpMethod;
        this.openTSDBHttpUri = openTSDBHttpUri;
        this.mqttMessage = mqttMessage;
        this.logger = logger;
    }

    //overload constructor; read config from file
    public OpenTSDBConnector(Logger logger, Properties props) {
        this.logger = logger;
        //Load other params from file  
        ConfigurationReader cr = new ConfigurationReader();
        Vector<String> Parameters = new Vector();
        Parameters.add("OPENTSDB_SERVER_IP");
        Parameters.add("OPENTSDB_ENDPOINT_PORT");
        Parameters.add("OPENTSDB_HTTP_METHOD");
        Parameters.add("OPENTSDB_HTTP_ENDPOINT_URI");

        logger.info("reading Kafka Topic and maximum reconnect attempts from config file");
        Vector<String> params = cr.getProperties(props, Parameters, logger);
        this.openTSDBServer = params.get(0);
        this.openTSDBPort = params.get(1);
        this.openTSDBHttpMethod = params.get(2);
        this.openTSDBHttpUri = params.get(3);

    }

    private boolean isOpenTSDBReacheable() throws IOException, OpenTSDBNotReachableException {
        //test is OpenTSDB reacheable
        String OpenTSDBEndpointUrl = "http://" + openTSDBServer + ":" + openTSDBPort;
        HttpClient client = HttpClientBuilder.create().build();
        HttpGet request = new HttpGet(OpenTSDBEndpointUrl);
        logger.info("Trying to connect to : " + OpenTSDBEndpointUrl);
        HttpResponse response = client.execute(request);
        int responseCode = response.getStatusLine().getStatusCode();
        logger.info("Http response code: " + responseCode);
        if (responseCode == 200) {
            logger.info("OpenTSDB endpoint is reachable");
            return true;
        }
        logger.error("A problem occured when connecting to OpenTSDB endpoint. Please verify permissions and/or OpenTSDB configuration");
        throw new OpenTSDBNotReachableException("connection to OpenTSDB failed exception");
    }

    public void testOpenTSDBConnection() {

        try {
            isOpenTSDBReacheable();

        } catch (IOException | OpenTSDBNotReachableException ex) {
            logger.fatal("Cannot reach OpenTSDB server. The program will exit, otherwise all messages will be lost. This is a preventive action to avoid  data loss ");
            logger.fatal("Exception occurred when connecting to openTSDB: " + ex);
            System.out.println(ex);
            System.exit(10);
        }

    }

//synchronous

    public void PostToOpenTSDB(Logger logger, String JSONEvent) {
        try {

            String openTSDBEndpoint = "http://" + openTSDBServer + ":" + openTSDBPort + openTSDBHttpUri;
            URL url = new URL(openTSDBEndpoint);
            URLConnection connection = url.openConnection();
            HttpURLConnection http = (HttpURLConnection) connection;
            http.setRequestMethod("POST");
            String HTTPRequestBody = JSONEvent;
            byte[] bson = HTTPRequestBody.getBytes(StandardCharsets.UTF_8);

            http.setRequestProperty("Content-Type", HTTP_BODY_CONTENT_TYPE);

            http.setDoOutput(true);
            http.connect();
            OutputStream os = http.getOutputStream();
            os.write(bson);
            int responseCode = http.getResponseCode();
            
            if (responseCode != HTTP_RESPONSE_SUCCESS_CODE && responseCode != HTTP_RESPONSE_SUCCESS_CODE_EMPTY_BODY) {
                System.out.println("code: " + responseCode);
                logger.error("cannot post event to OpenTSDB, an http error code " + responseCode + " was returned when posting the event: \n " + JSONEvent + " "
                        + "for more information about the error code please visit \n"
                        + " http://opentsdb.net/docs/build/html/api_http/index.html \n"
                        + "Section: Response Codes \n");
                //http.
            }
            
        } catch (Exception e) {
            System.out.println(e);
            logger.error("An error occurred when running the request: " + e);
        }

    }

}

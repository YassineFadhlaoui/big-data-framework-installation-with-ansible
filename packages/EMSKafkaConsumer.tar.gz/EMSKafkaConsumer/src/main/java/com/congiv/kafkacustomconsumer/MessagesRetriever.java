/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.congiv.kafkacustomconsumer;

import com.congiv.configReader.ConfigurationReader;
import com.congiv.schemas.KafkaMessageSchema;
import com.congiv.schemas.MqttMessage;
import com.congiv.schemas.MqttMessageFieldsIndexer;
import com.google.gson.Gson;
import java.util.Base64;
import java.util.HashMap;
import java.util.Properties;
import java.util.Vector;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.log4j.Logger;


/**
 *
 * @author yassine
 */
public class MessagesRetriever {

    private KafkaConsumer kafkaConsumer;
    private String delimiter;

    public MessagesRetriever(KafkaConsumer kafkaConsumer, String delimiter) {
        this.kafkaConsumer = kafkaConsumer;
        this.delimiter = delimiter;
    }
//read delimiter from conf file
    
       public MessagesRetriever(KafkaConsumer kafkaConsumer,Properties JAVAProps,Logger logger) {
        this.kafkaConsumer = kafkaConsumer;
                ConfigurationReader cr = new ConfigurationReader();
        Vector<String> Parameters = new Vector();

        Parameters.add("MQTT_FIELDS_DELIMITER");
        logger.info("reading MQTT message  fields delimiter from config file");
        Vector<String> params = cr.getProperties(JAVAProps, Parameters, logger);
        this.delimiter= params.get(0);
    } 
    private String payloadParser(String payload, Logger logger,Properties JAVAProps,MqttMessageFieldsIndexer mqttMessageIndexer) {
        //OpenTSDB  accept only alphanumeric values no :/'....
        //we trim the fields[4] (datestamp) and we remove all spaces and non-alphanumeric chars
        String transformedPayload = payload.replaceAll(mqttMessageIndexer.getOpenTSDBAllowedChars(), ".");
        String[] fields = transformedPayload.split(delimiter);

        
        try {
            String timestampStr = fields[mqttMessageIndexer.getTimestampPosition()];
            String metric = fields[mqttMessageIndexer.getMetricNamePosition()];
            String valueStr = fields[mqttMessageIndexer.getMetricValueposition()];
            HashMap<String, Object> tags = new HashMap<>();
            tags.put("ClientID", fields[mqttMessageIndexer.getClientIdPosition()]);
            tags.put("MeterUID", fields[mqttMessageIndexer.getMeterIdPosition()]);
            tags.put("Datestamp", fields[mqttMessageIndexer.getDatestampPosition()]);
            tags.put("UTCsecondsDelta", fields[mqttMessageIndexer.getUtcSecondsDeltaPosition()]);
            tags.put("MesureDelta", fields[mqttMessageIndexer.getDeltaValuePosition()]);
            if (fields.length == (mqttMessageIndexer.getMqttMessageFieldsNumber()-1)) {
                tags.put("Unit", "no_unit");
            } else {
                tags.put("Unit", fields[mqttMessageIndexer.getUnitPosition()]);
            }

            try {
                long timestamp = Long.parseLong(timestampStr);
                float value = Float.parseFloat(valueStr);
                MqttMessage mqttMessage = new MqttMessage(metric, timestamp, value, tags);

                Gson gson = new Gson();
                String HttpJsonPayload = gson.toJson(mqttMessage);
                return HttpJsonPayload;
            } catch (Exception ex) {

                logger.warn("Not able to parse parameters: timestamp: " + timestampStr + " and/or value: " + valueStr);
                return null;
            }

        } catch (Exception ex) {
            logger.error("cannot parse event: " + payload + " Exception: " + ex);
        }
        return null;
    }

    public void retrieveAndSaveMessages(Logger logger, Properties JAVAProps) {
        OpenTSDBConnector OpenTSDBDconnector = new OpenTSDBConnector(logger, JAVAProps);
        //Reading fields order from config file
        MqttMessageFieldsIndexer mqttMessageSchema = new MqttMessageFieldsIndexer(logger, JAVAProps);
        //now we loop infinetly and read kafka messages
        while (true) {
            //I will not log here. I need speed
            ConsumerRecords<String, String> records = kafkaConsumer.poll(100);
            for (ConsumerRecord<String, String> record : records) {
                //we read all records
                //we keep the kafka topic value
                String strKafkaMessage = (String) record.value();
                // System.out.println(strKafkaMessage);
                Gson gson = new Gson();
                //We cast the Kafka value to the OpenTSDB schema: 
                KafkaMessageSchema kafkamessage = gson.fromJson(strKafkaMessage, KafkaMessageSchema.class);
                String payload = kafkamessage.getPayload();
                byte[] decodedBytes = Base64.getDecoder().decode(payload);
                //System.out.println(new String(decodedBytes));
                String JSONPayload = payloadParser(new String(decodedBytes), logger,JAVAProps,mqttMessageSchema);
                if (JSONPayload != null) {
                    try {
                       
                        OpenTSDBDconnector.PostToOpenTSDB(logger, JSONPayload);
                        //OpenTSDBDconnector.PostToOpenTSDB(logger, JSONPayload);
                    } catch (Exception ex) {

                        System.out.println(ex);
                        logger.error("not able to post to OpenTSDB: " + ex);
                    }
                }
            }
        }

    }
}

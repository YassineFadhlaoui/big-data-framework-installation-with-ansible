/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.congiv.schemas;

import java.util.HashMap;

/**
 *
 * @author occ
 */
public class MqttMessage {
    String metric;
    Long timestamp;
    float value;
    HashMap<String, Object> tags;

    public MqttMessage(String metric, Long timestamp, float value, HashMap<String, Object> tags) {
        this.metric = metric;
        this.timestamp = timestamp;
        this.value = value;
        this.tags = tags;
    }

    public String getMetric() {
        return metric;
    }

    public Long getTimestamp() {
        return timestamp;
    }

    public float getValue() {
        return value;
    }

    public HashMap<String, Object> getTags() {
        return tags;
    }

    public void setMetric(String metric) {
        this.metric = metric;
    }

    public void setTimestamp(Long timestamp) {
        this.timestamp = timestamp;
    }

    public void setValue(float value) {
        this.value = value;
    }

    public void setTags(HashMap<String, Object> tags) {
        this.tags = tags;
    }
    
    
    
}

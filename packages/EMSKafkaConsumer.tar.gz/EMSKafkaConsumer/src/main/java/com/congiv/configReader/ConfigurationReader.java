/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.congiv.configReader;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.Vector;
import org.apache.log4j.Logger;

/**
 *
 * @author occ
 */
public class ConfigurationReader {

    

    @SuppressWarnings("UseOfObsoleteCollectionType")
    public Properties loadConfigFile(Logger logger, String configFile) {
        Properties prop = new Properties();
        InputStream input = null;

        try {

            input = new FileInputStream(configFile);
            prop.load(input);
            return prop;

        } catch (Exception e) {

            System.out.println("not able to load config file");
            logger.error("cannot load the configuration file");

        }
        return null;
    }

    public Vector<String> getProperties(Properties prop, Vector<String> parameters, Logger logger) {
        Vector<String> params = new Vector();

        for (String parameter : parameters) {
            try {
                params.add(prop.getProperty(parameter));
            } catch (Exception ex) {
                ex.printStackTrace();
                logger.error("Cannot read parameter: " + parameter + " form properties file ");
            }
        }

        return params;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.congiv.CustomLogger;

import com.congiv.kafkacustomconsumer.kafkaConsumer;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

/**
 *
 * @author occ
 */
public class CustomLogger {

    

    public static Logger getLogger(String log4jconfigFile) {
        Logger logger = Logger.getLogger(kafkaConsumer.class);
        PropertyConfigurator.configure(log4jconfigFile);
        return logger;
    }
}

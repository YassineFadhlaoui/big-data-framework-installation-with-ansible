/**
 *This is the main JAVA class that does the following tasks:
 * - verifying configuration files
 * - Logging
 * - subscribe to Kafka  Topics
 * -
 */
package com.congiv.kafkacustomconsumer;

import com.congiv.CustomException.BrokerConnectionException;
import com.congiv.CustomLogger.CustomLogger;
import com.congiv.configReader.ConfigurationReader;
import com.congiv.configReader.VerifyConfigFiles;
import java.io.IOException;
import java.util.Properties;
import java.util.logging.Level;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.log4j.Logger;

/**
 *
 * @author occ
 */
public class kafkaConsumer {
    
    private static final String JAVA_PROGRAM_CONFIG_FILE = "/etc/EMSKafkaConsumer/EMSKafkaConsumer.conf";
    private static final String KAFKA_SUBSCRIBER_CONFIG_FILE = "/etc/EMSKafkaConsumer/KafkaSubscriber.conf";
    private static final String LOG4J_CONFIG_FILE = "/etc/EMSKafkaConsumer/log4j.conf";
    
    public static void main(String[] args) {

        /**
         * Verifying configuration files. 
         * We start by verifying that all
         * configuration files are in place and have the correct (read/write
         * permissions) please refer to the java class VerifyConfigFiles for
         * more information about the config files and logging dir The program
         * will exit if the files are missing or don't have the write
         * permissions the exit code depends on the error
         *
         */
        VerifyConfigFiles verify = new VerifyConfigFiles();
        verify.isConfigFilesThere();

        /**
         * Now we instantiate a log4j instance.
         */
        Logger logger = CustomLogger.getLogger(LOG4J_CONFIG_FILE);

        /**
         * Loading the Configuration file of the JAVA program. this file
         * contains the program configuration (Kafka topic, max reconnect
         * attempts when the first connection failed ...)
         */
        ConfigurationReader configLoader = new ConfigurationReader();
        Properties javaProgramConsumerProperties = configLoader.loadConfigFile(logger, JAVA_PROGRAM_CONFIG_FILE);

        /**
         * Loading the Kafka subscriber file. this file describes the
         * subscribers characteristics (the group ID that the subscriber will be
         * part of, session timeout, topic value java desrializer class ) The
         * file is under /etc/EMSKafkaConsumer/KafkaSubscriber.conf
         */
        Properties kafkaSubscriberProperties = configLoader.loadConfigFile(logger, KAFKA_SUBSCRIBER_CONFIG_FILE);
        /**
         * Verify that the OpenTSDB http server is up.
         */
        OpenTSDBConnector openTSDBConnector = new OpenTSDBConnector(logger, javaProgramConsumerProperties);
        
        openTSDBConnector.testOpenTSDBConnection();
        /**
         * Connecting to the Kafka broker using the above properties. The topic
         * to be subscribed to is defined in the JAVA_PROGRAM_CONFIG_FILE Once
         * subscribed. We start by retrieving messages from that specific Topic.
         * The message is a String (JSON string) so we cast it to JAVA class
         * (KafkaMessageSchema.class) The message payload is what we want. it is
         * the MQTT message body
         */
        KafkaSubscriber kafka = new KafkaSubscriber(kafkaSubscriberProperties, javaProgramConsumerProperties, logger);
        try {
            KafkaConsumer kafkaConsumer = kafka.SubscribeToBroker(logger);
            //Now we retrieve mesages
            MessagesRetriever retriever = new MessagesRetriever(kafkaConsumer,javaProgramConsumerProperties, logger);
            retriever.retrieveAndSaveMessages(logger,javaProgramConsumerProperties);
        } catch (BrokerConnectionException ex) {
            System.out.println(ex);
        } catch (NullPointerException ex) {
            System.out.println("null consumer");
        }
        
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.congiv.schemas;

/**
 *
 * @author occ
 */
public class KafkaMessageSchema {
    private KafkaSchema schema;
    private String payload;

    public KafkaMessageSchema(KafkaSchema schema, String payload) {
        this.schema = schema;
        this.payload = payload;
    }

    public KafkaSchema getSchema() {
        return schema;
    }

    public String getPayload() {
        return payload;
    }

    @Override
    public String toString() {
        return "KafkaMessageSchema{" + "schema=" + schema + ", payload=" + payload + '}';
    }
   
}

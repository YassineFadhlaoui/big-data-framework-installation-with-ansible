/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.congiv.CustomException;

/**
 *
 * @author occ
 */
public class OpenTSDBNotReachableException extends Exception {

    public OpenTSDBNotReachableException() {
        super();
    }

    public OpenTSDBNotReachableException(String message) {
        super(message);
    }

    public OpenTSDBNotReachableException(String message, Throwable cause) {
        super(message, cause);
    }

    public OpenTSDBNotReachableException(Throwable cause) {
        super(cause);
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.congiv.schemas;

/**
 *
 * @author occ
 */
public class KafkaSchema {
    private String type;
    private String optional;

    public KafkaSchema(String type, String optional) {
        this.type = type;
        this.optional = optional;
    }

    public String getType() {
        return type;
    }

    public String getOptional() {
        return optional;
    }

    @Override
    public String toString() {
        return "KafkaSchema{" + "type=" + type + ", optional=" + optional + '}';
    }
    
    
}
